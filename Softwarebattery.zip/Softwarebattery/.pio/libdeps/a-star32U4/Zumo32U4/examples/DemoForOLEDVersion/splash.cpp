#include <Arduino.h>

#define zumo_32u4_splash_bits unused_placeholder; extern const uint8_t PROGMEM zumo32U4Splash
#include "zumo_32u4_splash.h"
